        case 4:
            index = int(input('Insira a a posição do elemento a  ser mostrado: '))
            print(lista.show_index(index))